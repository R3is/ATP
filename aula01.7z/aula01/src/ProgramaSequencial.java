/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author 1229165
 */
public class ProgramaSequencial {

 
    public static void main(String[] args) {
         int num1,num2,soma; /*qualquer defininção java termina com ponto virgula*/ 
         float a, b,x;
    num1= 3;
    num2= 4;
    /*soma= num1+num2;
    System.out.println("A soma eh " + soma); //este '+' eh simbolo de concatenação e não operação matematica//
    */
         
     a = num1;
     b= num2;
     x = -b/a;
            
    System.out.println("o valor de x eh " + x );
            
    
            
    
            
    
   

   
    }
    
}
