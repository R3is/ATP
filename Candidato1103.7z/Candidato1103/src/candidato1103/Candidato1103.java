/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package candidato1103;

import java.util.Scanner;

/**
 *
 * @author 1229165
 */
public class Candidato1103 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     int c1,c2,c3,c4,c5,aux1,aux2;
    Scanner ent= new Scanner (System.in);
    System.out.println("Digite os votos do primeiro candidato");
    c1= ent.nextInt();
    
    System.out.println("Digite os votos do candidato");
    c2= ent.nextInt();
    
    System.out.println("Digite os votos do candidato");
    c3= ent.nextInt();
    
    System.out.println("Digite os votos do candidato");
    c4= ent.nextInt();
    
    System.out.println("Digite os votos do candidato");
    c5= ent.nextInt();
        
    
    
    
    
    }
    
}
